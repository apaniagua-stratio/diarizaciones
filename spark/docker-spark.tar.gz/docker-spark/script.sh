val classDriver="net.sourceforge.jtds.jdbc.Driver"
val url="jdbc:jtds:sqlserver://169.254.0.2/master"
val opts=new java.util.Properties
opts.put("user","sa")
opts.put("password","zKMnkjvih4aB8SqT")
opts.put("Driver", classDriver)

spark.read.jdbc(url,"dbo.xpolizas_comun",opts).registerTempTable("xpolizas_comun")



